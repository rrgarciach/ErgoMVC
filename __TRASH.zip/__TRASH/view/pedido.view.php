<?php

require_once "../model/pedidos.model.php";
$pedidoModel = new PedidoModel();
$pedidoModel->abrirPedido("id_cliente", 135);
$pedidoModel->toString();


require_once "../model/producto.model.php";
$productoModel = new ProductoModel();
$productoModel->abrirProducto("id_codigo", 22606);
$productoModel->toString();

?>