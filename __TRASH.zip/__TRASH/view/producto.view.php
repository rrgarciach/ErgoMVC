<?php
require_once "view/view.php";
class Seccion extends View {
	private $level = 1;

	public function getLevel() {
		return $this->level;
	}

}
?>

<?php
require_once "controller/producto.controller.php";
$productoController = new ProductoController();
$productoController->abrirProducto("id_codigo", 22606);

echo $productoController->toString(); 
?>