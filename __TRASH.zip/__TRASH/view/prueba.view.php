<?php
require_once "view/view.php";
class Seccion extends View {

	private $acceso = "publico";
	private $title = "Prueba";
	private $html = "<h1>Pagina de Prueba</h1>";

	public function acceso() {
		parent::setAcceso($this->acceso);
		setTitle($this->title);
	}

	public function getHtml() {
		return $this->html;
	}




}
?>