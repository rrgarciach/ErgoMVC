<?php
	define("ADMIN", 1);
	define("USER", 0);

abstract class View {

	private $acceso;
	private $title;

	private function acceso() {
		if ( isset($_SESSION) ) {
			switch ($_SESSION['usuario_privilegios']) {
				case 1:
					
					break;
				
				default:
					# code...
					break;
			}
		} else {
			header("Location: ?p=prueba");
		}
	}

	protected function setAcceso( $int ) {
		$this->acceso = $int;
		$this->acceso();
	}

	public function aetTitle( $string ) {
		$this->title = $string;
	}
	public function getTitle() {
		return $this->title;
	}


}