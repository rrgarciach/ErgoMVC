<?php

class PedidosModel {

	private $id_pedido = null;
	private $id_cliente = null;
	private $id_vendedor = null;
	private $fecha = null;
	private $notas = "";
	private $estatus = "";
	private $productos = array();


	public function abrirPedido( $atributo, $valor, $clausula="" ) {

		require_once "../controller/pedidos.controller.php";
		$pedidoController = new PedidoController();
		$arrayRecibido = $pedidoController->leerPedido($atributo, $valor, $clausula, 1);
		$this->id_pedido = $arrayRecibido['id_pedido'];
		$this->id_cliente = $arrayRecibido['id_cliente'];
		$this->fecha = $arrayRecibido['fecha'];
		$this->notas = $arrayRecibido['notas'];
		$this->estatus = $arrayRecibido['estatus'];
		$this->productos = $this->abrirProductos( $this->id_pedido );

	}

	public function abrirProductos( $id_pedido ) {

		require_once "../controller/pedidos.controller.php";
		$pedidoController = new PedidoController();
		return $pedidoController->productosPedido($this->id_pedido);

	}

	public function toString() {

		echo "<h3>Detalle del Pedido</h3>";
		echo "No. Pedido: ".$this->id_pedido."<br />";
		echo "No. Cliente: ".$this->id_cliente."<br />";
		echo "No. Vendedor: ".$this->id_vendedor."<br />";
		echo "Fecha: ".date("d-M-Y", strtotime($this->fecha))."<br />";
		echo "Notas: ".$this->notas."<br />";
		echo "Estatus: ".$this->estatus."<br />";
		echo "Productos:";
		echo $this->productos['id_codigo'];
		print_r($this->productos);
		while ($producto = $this->productos) {
			echo "Codigo: ".$producto['id_codigo'];
			echo " - Descripcion: ".$producto['descripcion'];
			echo " - Precio: ".$producto['p_distribuidor_IVA']."<br />";
		}

	}

}

?>