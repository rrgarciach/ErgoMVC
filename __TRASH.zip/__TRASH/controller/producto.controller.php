<?php

class ProductoController {

	private $id_codigo = null;
	private $descripcion = null;
	private $caja = 0;
	private $master = 0;
	private $unidad = 0;
	private $ean = 0;
	private $p_distribuidor_IVA = 0;
	private $lleva_IVA = 0;
	private $imagen = 0;
	private $estante = 0;
	private $anaquel = 0;
	private $id_proveedor = 0;

	public function abrirProducto( $atributo, $valor, $clausula="", $limite=0 ) {

		require_once "model/producto.model.php";
		$productoModel = new ProductoModel();
		$arrayRecibido = $productoModel->leerProducto($atributo, $valor, "", 1);
		$this->id_codigo = $arrayRecibido['id_codigo'];
		$this->descripcion = $arrayRecibido['descripcion'];
		$this->caja = $arrayRecibido['caja'];
		$this->master = $arrayRecibido['master'];
		$this->unidad = $arrayRecibido['unidad'];
		$this->ean = $arrayRecibido['ean'];
		$this->p_distribuidor_IVA = $arrayRecibido['p_distribuidor_IVA'];
		$this->lleva_IVA = $arrayRecibido['lleva_IVA'];
		$this->imagen = $arrayRecibido['imagen'];
		$this->estante = $arrayRecibido['estante'];
		$this->anaquel = $arrayRecibido['anaquel'];
		$this->id_proveedor = $arrayRecibido['id_proveedor'];

	}

	public function abrirProductos( $atributo, $valor, $clausula="", $limite=0 ) {

		require_once "model/producto.model.php";
		$productoModel = new ProductoModel();
		$arrayRecibido = $productoModel->leerProducto($atributo, $valor, $clausula, $limite);
		return $arrayRecibido;

	}

	public function toString() {

		$str = "<h3>Detalle del Producto</h3>";
		$str .= "Codigo: ".$this->id_codigo."<br />";
		$str .= "Descripcion: ".$this->descripcion."<br />";
		$str .= "Caja: ".$this->caja."<br />";
		return $str;

	}

}

?>