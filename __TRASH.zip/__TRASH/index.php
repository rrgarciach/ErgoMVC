<?php 
class Pagina {

  /* Variables de la clase */
  private $pagina = "prueba";
  private $paginaTitulo = "Distribuidora GC";

  public function setPage( $string ) {
    $this->pagina = $string;
  }
  public function getPage () {
    return $this->pagina;
  }

  public function setPageTitle( $string ) {
    $this->paginaTitulo = $string;
  }
  public function getPageTitle() {
    return $this->paginaTitulo;
  }

  public function cargarPagina() {
    if( isset($_GET['p']) ) $this->setPage( $_GET['p'] );
    /* Abre el contenido de la página/sección */
    require "view/".$this->getPage().".view.php";
    $seccion = new Seccion();
    return $seccion;
  }

}

$pagina = new Pagina();
$seccion = $pagina->cargarPagina();
$seccion->acceso();

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title><?php echo $seccion->getTitle(); ?></title>
  <meta name="description" content="<?php echo $pageDesc; ?>">
  <meta name="keywords" content="<?php echo $pageKeywords; ?>">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="facebox/facebox.css">
  <script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
  <script type="text/javascript" src="js/cufon-yui.js"></script>
  <script type="text/javascript" src="js/Myriad_Pro_700.font.js"></script>
  <script type="text/javascript" src="js/jquery.jcarousel.min.js"></script>
  <script type="text/javascript" src="js/functions.js"></script>
  <script type="text/javascript" src="facebox/facebox.js"></script>
  <script type="text/javascript">$(document).ready(function(){
    jQuery(document).ready(function($) { $('a[rel*=facebox]').facebox() })
  })</script>
</head>
<body><!-- Begin Wrapper -->
  <div id="wrapper">
    <!-- Begin Header -->
    <div id="header">
      <!-- Begin Shell -->
      <div class="shell">
        <h1 id="logo"><a class="notext" href="index.php" title="Distribuidora GC">Distribuidora GC</a></h1>
        <div id="top-nav"><ul><li><a href="login_window.php" rel="facebox" ><span>Iniciar Sesión</span></a></li></ul>
        </div>
        <div class="cl">&nbsp;</div>
        <p id="cart"><span class="profile">Bienvenido, aún no ha iniciado <a href="#" title=".">sesión de usuario</a> . </span></p>
      </div>
      <!-- End Shell -->
    </div>
    <!-- End Header -->
    <!-- Begin Navigation -->
    <div id="navigation">
      <!-- Begin Shell -->
      <div class="shell">
        <ul>
          <li>
            <a href="#"><img src="images/order_close.png">PROMOCIONES DEL MES</a>
          </li>
          <li>
            <a href="#"><img src="images/order_close.png">CATALOGO EN LINEA</a>
          </li>
          <li>
            <a href="#"><img src="images/order_close.png">SERVICIOS</a>
            <div class="dd">
              <ul>
                <li>
                  <a href="#">SISTEMAS FOTOVOLTAICOS</a>
                </li>
                <li>
                  <a href="#">ASESORIA EN HERRAMIENTA</a>
                </li>
                <li>
                  <a href="#">ASESORIA EN MAQUINARIA</a>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <a href="#"><img src="images/order_close.png">CONTACTO</a>
            <div class="dd">
              <ul>
                <li>
                  <a href="#">ATENCION A CLIENTES</a>
                </li>
                <li>
                  <a href="#">SOPORTE TECNICO</a>
                </li>
              </ul>
            </div>
          </li>
        </ul>
        <div class="cl">&nbsp;</div>
      </div>
      <!-- End Shell -->
    </div>
    <!-- End Navigation -->

    <!-- Begin Slider -->
    <div id="slider">
      <!-- Begin Shell -->
      <div class="shell">
        <ul class="slider-items"><li>
         <img src="images/slide-img1.jpg" alt="Slide Image">
         <div class="slide-entry">
          <!--<h2><span>Generador eléctrico a gasolina,<br>industrial </span>7,000 W</h2>
          <h6>NUEVO MODELO DE<br>
            MAYOR POTENCIA<br>
            PARA COMPLEMENTAR<br>
            NUESTRA LÍNEA</ h6>-->
            <a href="https://www.facebook.com/pages/Distribuidora-GC/116334158538331" target="_blank" class="buttonMain" title="VISITANOS"><span>¡VISITANOS!</span></a>
          </div>
        </li><li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/18006.jpg" alt="picture_not_found"><h2>V&aacute;lvula check de lat&oacute;n de 1/2"</h2>
          <h5>$ 75.40 MXN / Pieza</h5>
          <a href="#" class="buttonMain" title="18006"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/2602.jpg" alt="picture_not_found"><h2>Broca para router, media ca&ntilde;a, 3/4"</h2>
          <h5>$ 75.40 MXN / Pieza</h5>
          <a href="#" class="buttonMain" title="2602"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/14606.jpg" alt="picture_not_found"><h2>Cortador de azulejos, de mesa, 4-1/2'', industrial</h2>
          <h5>$ 1,096.20 MXN / Pieza</h5>
          <a href="#" class="buttonMain" title="14606"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/2709.jpg" alt="picture_not_found"><h2>Cord&oacute;n duplex flexible SPT, 12 AWG</h2>
          <h5>$ 1,421.00 MXN / Caja</h5>
          <a href="#" class="buttonMain" title="2709"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/10212.jpg" alt="picture_not_found"><h2>Guantes de carnaza, cortos, Pretul</h2>
          <h5>$ 42.92 MXN / Par</h5>
          <a href="#" class="buttonMain" title="10212"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/11103.jpg" alt="picture_not_found"><h2>Hidrolavadora el&eacute;ctrica, 1550 PSI, Pretul</h2>
          <h5>$ 1,450.00 MXN / Pieza</h5>
          <a href="#" class="buttonMain" title="11103"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/0805.jpg" alt="picture_not_found"><h2>Tri&aacute;ngulo de seguridad, de pl&aacute;stico, 43.5 cm</h2>
          <h5>$ 127.60 MXN / Pieza</h5>
          <a href="#" class="buttonMain" title="0805"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/12505.jpg" alt="picture_not_found"><h2>Llave espa&ntilde;ola, 5/8 x 11/16" x 185 mm</h2>
          <h5>$ 71.92 MXN / Pieza</h5>
          <a href="#" class="buttonMain" title="12505"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/16102.jpg" alt="picture_not_found"><h2>Pilas recargables AA, 2 piezas , Voltech</h2>
          <h5>$ 75.40 MXN / Par</h5>
          <a href="#" class="buttonMain" title="16102"><span>AGREGAR</span></a>
        </div>
      </li>
      <li>
        <img src="images/slide-img0.jpg" alt="Slide Image">
        <div class="slide-entry">
          <img src="images/products/20808.jpg" alt="picture_not_found"><h2>Tijera para hojalatero 10"</h2>
          <h5>$ 145.00 MXN / Pieza</h5>
          <a href="#" class="buttonMain" title="20808"><span>AGREGAR</span></a>
        </div>
      </li>
    </ul>
    <div class="cl">&nbsp;</div>
    <div class="slider-nav">
    </div>
  </div>
  <!-- End Shell -->
</div>
<!-- End Slider -->
<!-- Begin Main -->
<div id="main" class="shell">
 <!-- Begin Content -->
 <div id="content">
<div class="post">
  <?php echo $seccion->getHtml(); ?>
</div>

  <div class="post">
   <h2>Generador eléctrico a gasolina 5,500 W</h2>
   <img src="images/posts/generador.jpg" alt="Post Image">
   <p>Motor de 4 tiempos</p>
   <p>Diseño compacto para fácil transporación con redas y manubrio abatible</p>
   <p>Protege los aparatos eléctricos ya que cumple con el voltaje y la frecencia indicados, incluso al operarlo con carga nominal</p>
   <p>El generador más silencioso en su categoría</p>
   <p>Contamos con Centros de Servicio y REfacciones</p>
   <p>Ciclo de trabajo: Trabajo continuo a potencia nominal / 30 min. de descanso x tanque consumido.<!--<a href="#" class="more" title="Seguir leyendo...">Seguir leyendo...</a>--></p>
   <div class="cl">&nbsp;</div>
 </div>
</div>
<!-- End Content -->
<div class="cl">&nbsp;</div>
</div>
<!-- End Main -->
</div>
<!-- End Wrapper --><!-- Begin Footer -->
<div id="footer">
  <div class="boxes">
    <!-- Begin Shell -->
    <div class="shell">
      <div class="box post-box">
        <h2>Acerca de Distribuidora GC</h2>
        <div class="box-entry">
          <img src="images/bottom-logo.png" alt="Distribuidora GC">
          <p>Alcanzar y mantener un lugar tan destacado en la industria ferretera ha sido posible gracias a una filosofía de trabajo que nos impulsa a realizar nuestras actividades diarias con la máxima eficiencia. Así nos aseguramos de que cada artículo que vendemos con nuestras marcas cumple nuestra promesa de calidad: poner en el mercado los productos con la mejor calidad en su categoría, incluidas aquellas en las que no somos líderes absolutos.</p>
          <p>A lo largo de los años esta filosofía ha ido permeando a todos los colaboradores que se han incorporado a nuestras filas, seleccionados por su actitud positiva y entrega al trabajo hecho con excelencia.
            <div class="cl">&nbsp;</div>
          </div>
        </div>
        <div class="box social-box">
          <h2>Síguenos en:</h2>
          <ul>
            <li><a href="https://www.facebook.com/pages/Distribuidora-GC/116334158538331" title="Facebook" target="_blank"><img src="images/social-icon1.png" alt="Facebook"><span>Facebook</span><span class="cl">&nbsp;</span></a></li>
            <li><a href="#" title="Twitter"><img src="images/social-icon2.png" alt="Twitter"><span>Twitter</span><span class="cl">&nbsp;</span></a></li>
          </ul>
          <div class="cl">&nbsp;</div>
        </div>
        <div class="box">
          <h2>Información</h2>
          <ul>
            <li><a href="#" title="Special Offers">Special Offers</a></li>
            <li><a href="#" title="Privacy Policy">Privacy Policy</a></li>
            <li><a href="#" title="Terms &amp; Conditions">Terms &amp; Conditions</a></li>
            <li><a href="#" title="Contact Us">Contact Us</a></li>
            <li><a href="#" title="Log In">Log In</a></li>
            <li><a href="#" title="Account">Account</a></li>
            <li><a href="#" title="Basket">Basket</a></li>
          </ul>
        </div>
        <div class="box last-box">
          <h2>Categorías</h2>
          <ul>
            <li><a href="#" title="Kids">Kids</a></li>
            <li><a href="#" title="Accessories">Accessories</a></li>
          </ul>
        </div>
        <div class="cl">&nbsp;</div>
      </div>
      <!-- End Shell -->
    </div>
    <div class="copy">
      <!-- Begin Shell -->
      <div class="shell">
        <div class="carts">
          <ul>
            <li><span>Aceptamos pagos con: </span></li>
            <li><a href="#" title="VISA"><img src="images/cart-img2.jpg" alt="VISA"></a></li>
            <li><a href="#" title="MasterCard"><img src="images/cart-img3.jpg" alt="MasterCard"></a></li>
            <li><a href="#" title="Payworks"><img src="images/banorte-payworks.png" height="24" alt="Payworks"></a></li>
            <li><a href="#" title="SSL"><img src="images/ssl.png" height="24" alt="SSL"></a></li>
          </ul>
        </div>
        <p>&copy; www.DistribuidoraGC.com. Todos los derechos reservados.<br>Versión 0.1a. Ultima actualización: 12/01/2012.</p>
        <div class="cl">&nbsp;</div>
      </div>
      <!-- End Shell -->
    </div>
  </div>
  <!-- End Footer -->
</body>
</html>