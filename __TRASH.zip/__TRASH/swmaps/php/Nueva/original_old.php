<?php
/**
 * PHP + GoogleMaps API
 * @author Ruy García
 * @version 31-07-2013
 */

/* Seleccionar el DBMS a usar. */
require_once "mysql.class.php";
#require_once "informix.class.php";

/* Inicio de la conección. */
$conn = new Connection();
/* @param database El nombre de la base de datos a usar. */
$conn->connectR("house");
/* @param query El query a enviar al DBMS. */
$rows = $conn->queryR("SELECT id, x, y, description FROM maps");

/* Declaración de variables para manejar en el codigo HTML los registros a recibir. */
$mapTags = array();

/* Loop para capturar los registros encontrados. */
do {
  $row=current($rows);

  /* Maneja las variables declaradas aquí. */
  /*
  $tag =array();
  array_push($tag, $row['id'], $row['x'], $row['y'], $row['description']);
  array_push($mapTags, $tag); // array de arrays
  */
  $id=$row['id'];
  $x=$row['x'];
  $y=$row['y'];
  $description=$row['description'];
  /* Termina el manejo de variables */

  //print_r($rows);
  $row=next($rows);
}
while ( next($rows) != false );
?>

<!DOCTYPE HTML>
<html>
  <head>
    <title>My Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://code.jquery.com/mobile/1.2.0/jquery.mobile-1.2.0.min.css">
    <script src="scripts\jquery.mobile.custom.js"></script>
    <script src="scripts\jquery.mobile.custom.min.js"></script>
    <script src="http://code.jquery.com/jquery-1.8.2.min.js"></script>
    <script src="http://code.jquery.com/mobile/1.2.0/jquery.mobile-1.2.0.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="../ui/jquery.ui.map.js"></script>
    <script src="../ui/jquery.ui.map.services.js"></script>
    <script src="../ui/jquery.ui.map.extensions.js"></script>
    <!--<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=AIzaSyCsJsnOtxKDdYF26MDoijX0Yqdw4f1Ldqg&sensor=false"></script>-->
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDx5hj10HChnrmakzQfaC0-dc_djuF-xTw&sensor=false"></script>
    <script>
    function init() {
      console.log('termino el init');
      var mapOptions = {
        center: new GLatLng(-34.397, 150.644), zoom: 8, mapTypeId: google.maps.MapTypeId.ROADMAP
      };
      var map = new GMap2(document.getElementById('map_canvas'));
      map.setCenter(new GLatLng(<?php echo $x.", ".$y ?>), 13);
      map.setUIToDefault();
      showData();

      var myLatlng = new google.maps.LatLng(<?php echo $x.", ".$y ?>);
      var mapOptions = {
        zoom: 4,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
      }
      var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);

      console.log('termino el init');
    }
    function firstXml() {
      xmlhttp = new XMLHttpRequest();
      xmlhttp.open('get','http://127.0.0.1/XML/prueba2.xml', true);
      xmlhttp.send();
      xmlDoc = xmlhttp.responseXML;
      if (xmlDoc != null) {
        console.log('no es nulo');
        return xmlDoc;
      }
      return false;
    }
    function showData() {
      xml = firstXml();
      if (xml == null) {
        alert('Nulo');
      }
      document.getElementById('map_canvas').innerHtml =xml.getElementsByTagName('Folio-1')[0].nodeValue;
    }
  </script>
  </head>
  <body onload="init()">
    <div data-role="page">
      <div data-role="header">
        <h1>My Title</h1>
      </div><!-- /header -->
      <div id="map_canvas" style="width: 800px; height: 600px">
        <h1>Mapa</h1>
      </div>
      <div i style="width: 500px; height: 300px">
        <h1>XML</h1>
        <p d="xml_canvas"></p>
      </div>
      <div data-role="content">
        <p>Hello world</p>
        <button href="#" data-role="button" data-icon="star">hide</button>
        <a href="http://127.0.0.1/pruebaDB.php" data-role="button" data-icon="star">Make Xml</a>
      </div><!-- /content -->
      <div data-role="footer">
        <h4>My Footer</h4>
      </div><!-- /footer -->
    </div><!-- /page -->
  </body>
</html>