<?php

class Connection {

    private $writeServerURL = "127.0.0.1";
    private $writeUser      = "root";
    private $writePassword  = "";
    private $writeUDB_write   = "";

    private $readServerURL  = "127.0.0.1";
    private $readUser       = "root";
    private $readPassword   = "";
    private $readDB_read    = "";

    function connectR($database, $userid, $password) {
        $conn_id = ifx_connect ($database, $userid, $password);
    }

    function closeR($conn) {
        ifx_close($conn);
    }

    function connR() {
        return $this->readDB_read;
    }

    function queryR($query, $connType) {
        //$rid = ifx_prepare ("select * from emp where name like " . $name, $connid, IFX_SCROLL);
        $rid = ifx_prepare ($query, $this->connR() );

        if (! $rid) {
                echo 'Could not select database';
            }
        $rowcount = ifx_affected_rows($rid);
            if ($rowcount > 1000) {
                printf ("Too many rows in result set (%d)\n<br />", $rowcount);
                die ("Please restrict your query<br />\n");
            }
        if (! ifx_do ($rid)) {
                /* ... error ... */
            }
        $row = ifx_fetch_row ($rid, "NEXT");
        $rows = array();
        while (is_array($row)) {
            array_push($rows, $row);
            $row = ifx_fetch_row($rid, "NEXT");
        }
        ifx_free_result ($rid);
        return $rows;
    }

}

?>