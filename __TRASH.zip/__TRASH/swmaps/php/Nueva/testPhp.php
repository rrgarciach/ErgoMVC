<?php
echo("<!doctype html>");
echo("<html>");
echo("<head>");
    echo("<title>My Page</title>");
    echo("<meta name='viewport' content='width=device-width, initial-scale=1'>");
    echo("<link rel='stylesheet' href='http://code.jquery.com/mobile/1.2.0/jquery.mobile-1.2.0.min.css'>");
    echo("<script src='scripts\jquery.mobile.custom.js'></script>");
    echo("<script src='scripts\jquery.mobile.custom.min.js'></script>");
    echo("<script src='http://code.jquery.com/jquery-1.8.2.min.js'></script> ");
    echo("<script src='http://code.jquery.com/mobile/1.2.0/jquery.mobile-1.2.0.min.js'></script>");
    echo("<script src='http://maps.google.com/maps/api/js?sensor=true'></script>");
    echo("<script  src='../ui/jquery.ui.map.js'></script>");
    echo("<script  src='../ui/jquery.ui.map.services.js'></script>");
    echo("<script  src='../ui/jquery.ui.map.extensions.js'></script>");
    echo("<script src='http://maps.google.com/maps?file=api&amp;v=2&amp;key=AIzaSyCsJsnOtxKDdYF26MDoijX0Yqdw4f1Ldqg&sensor=false'></script>");

    echo("<script>");
      echo("function init() {");
                    
            echo("console.log('termino el init');");
                echo("var mapOptions ={");
                      echo("center: new GLatLng(-34.397, 150.644),");
                            echo(" zoom: 8,");
                                  echo("  mapTypeId: google.maps.MapTypeId.ROADMAP");
                                echo("};");
              echo(" var map = new GMap2(document.getElementById('map_canvas'));");
                echo(" map.setCenter(new GLatLng(28.6657928,-106.0641978), 13);");
                 echo("map.setUIToDefault();");
                 echo("showData();");
                 echo("console.log('termino el init');");
                echo("}");
    echo("function firstXml() {");
        echo("xmlhttp=new XMLHttpRequest();");
        echo("xmlhttp.open('get','http://127.0.0.1/XML/prueba2.xml',true);");
        echo("xmlhttp.send();");
        echo("xmlDoc=xmlhttp.responseXML;");
        echo("if (xmlDoc != null) {");
            echo("console.log('no es nulo');");
        echo("return xmlDoc;");
      echo(" }");
        echo("return false;");
    echo("}");
    
   echo(" function showData() {");
        echo("xml = firstXml();");
        echo("if (xml == null) {");
            echo("alert('Nulo');");
        echo("}");
        echo("document.getElementById('map_canvas').innerHtml =xml.getElementsByTagName('Folio-1')[0].nodeValue;");
    echo("}");
    echo("</script>");
echo("</head>");
echo("<body onload='init()'>");
    echo("<div data-role='page'>");
 
        echo("<div data-role='header'>");
            echo("<h1>My Title</h1>");
        echo("</div><!-- /header -->");
        
       echo(" <div id='map_canvas' style='width: 800px; height: 600px'>");
             echo("   <h1>Mapa</h1>");
        echo("</div>");
 echo("<div i style='width: 500px; height: 300px'>");
    echo("<h1>XML</h1>");
    echo("<p d='xml_canvas'>");
    echo("</p>");
 echo("</div>");
       echo(" <div data-role='content'>");
            echo("<p>Hello world</p>");
          
        echo("<button href='#' data-role='button' data-icon='star'>hide</button>");
        echo("<a href='http://127.0.0.1/pruebaDB.php' data-role='button' data-icon='star'>Make Xml</a>");
        
       echo(" </div><!-- /content -->");
 
           
              
                
echo("<div data-role='footer'>");
      echo("<h4>My Footer</h4>");
        echo("</div><!-- /footer -->");
 
    echo("</div><!-- /page -->");
echo("</body>");
echo("</html>");
?>