<?php

require_once "maps.php";
require_once "sqlserver_class.php";

$conn = new SQLServer("w", "house1234");
//$params=array("x" => "999");
$rows = $conn->queryObject("SELECT * FROM maps", "Maps");
do {
	$row=current($rows);
	$row->printMap();
}
while ( next($rows) != false );

$conn->close();

?>