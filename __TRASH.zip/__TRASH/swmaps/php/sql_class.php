<?php

abstract class SQL_class {

    abstract function connect();

    abstract function close();

    abstract function query($query);

}

?>