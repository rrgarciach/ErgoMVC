<?php

class Maps {
	private $id;
	private $x;
	private $y;
	private $description;
	private $timestamp;

	public function __construct(){
	}

	public function printMap(){
		echo "id: ".$this->id."<br />x: ".$this->x."<br />y: ".$this->y."<br />description: ".$this->description."<br />timestamp: ".$this->timestamp."<br />";
	}

}

?>