<?php
/**
 * PHP + GoogleMaps API
 * @author Ruy García
 * @version 31-07-2013
 */

/* Seleccionar el DBMS a usar. */
require_once "mysql_class.php";
require_once "sqlserver_class.php";

/* Inicio de la conección.
* @param userType El tipo de usuario/privilegios para conexión.
* @param database El nombre de la base de datos a usar.
*/
//$conn = new MySQL("r", "house");
$conn = new SQLServer("w", "house1234");

/* @param query El query a enviar al DBMS. */
$rows = $conn->query("SELECT id, x, y, description FROM maps");

/* Cierre de la conexión. */
$conn->close();

/* Declaración de variables para manejar en el codigo HTML los registros a recibir. */
$mapTags = array();

/* Loop para capturar los registros encontrados. */
do {

  // Recorre el si
  $row=current($rows);
  $tag =array();

  // Maneja las variables declaradas aquí.
  $tag['id'] = $row['id'];
  $tag['x'] = $row['x'];
  $tag['y'] = $row['y'];
  $tag['description'] = $row['description'];

  // Array de arrays.
  array_push($mapTags, $tag);

}
while ( next($rows) != false );

?>

<!DOCTYPE HTML>
<html>
  <head>
    <title>My Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://code.jquery.com/mobile/1.2.0/jquery.mobile-1.2.0.min.css">
    <script src="scripts\jquery.mobile.custom.js"></script>
    <script src="scripts\jquery.mobile.custom.min.js"></script>
    <script src="http://code.jquery.com/jquery-1.8.2.min.js"></script>
    <script src="http://code.jquery.com/mobile/1.2.0/jquery.mobile-1.2.0.min.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="../ui/jquery.ui.map.js"></script>
    <script src="../ui/jquery.ui.map.services.js"></script>
    <script src="../ui/jquery.ui.map.extensions.js"></script>
    <!--<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=AIzaSyCsJsnOtxKDdYF26MDoijX0Yqdw4f1Ldqg&sensor=false"></script>-->
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDx5hj10HChnrmakzQfaC0-dc_djuF-xTw&sensor=true"></script>
    <script>
    
    <?php
    foreach ($mapTags as $tag) {
      echo "var tag".$tag['id']."=new google.maps.LatLng(".$tag['x'].", ".$tag['y'].");";
      echo "var marker".$tag['id']." = new google.maps.Marker({
        position:tag".$tag['id'].",
        title:\"".$tag['description']."\",
        animation:google.maps.Animation.DROP
        });";
    }
    ?>

    function initialize()
    {
    var mapOptions = {
      center:new google.maps.LatLng(28.667696,-106.034889),
      zoom:11,
      mapTypeId:google.maps.MapTypeId.ROADMAP
      };
    var map=new google.maps.Map(document.getElementById("map_canvas")
      ,mapOptions);

    <?php
    foreach ($mapTags as $tag) {
      echo "marker".$tag['id'].".setMap(map);";
    }
    ?>
    
    }

    google.maps.event.addDomListener(window, 'load', initialize);
    </script>
  </head>
  <body onload="init()">
    <div data-role="page">
      <div data-role="header">
        <h1>Usted esta aqui</h1>
      </div><!-- /header -->
      <div id="map_canvas" style="width:800px;height:600px;"></div>
      <div i style="width: 500px; height: 300px">
        <h1>XML</h1>
        <p d="xml_canvas"></p>
      </div>
      <div data-role="content">
        <p>Hello world</p>
        <button href="#" data-role="button" data-icon="star">hide</button>
        <a href="http://127.0.0.1/pruebaDB.php" data-role="button" data-icon="star">Make Xml</a>
      </div><!-- /content -->
      <div data-role="footer">
        <h4>My Footer</h4>
      </div><!-- /footer -->
    </div><!-- /page -->
  </body>
</html>