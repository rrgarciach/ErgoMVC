<?php
require_once "sql_class.php";

class SQLServer extends sql_class {

    private $server;
    private $user;
    private $password;
    private $connection;
    private $database;
    private $loginTimeOut;
    private $Encrypt;
    private $connectionOptions;

    function __construct( $userType, $database ) {
        switch ($userType) {
            
            /* Privilegios para lectura y escritura */
            case 'w':
                $this->server       = "house1234.db.8814249.hostedresource.com";
                $this->user         = "house1234";
                $this->password     = "Qwer1234!";
                $this->database     = $database;
                $this->loginTimeOut = 30;
                $this->Encrypt      = 1;
                $this->connectionOptions = array("UID" => $this->user, "pwd" => $this->password, "Database" => $this->database);
                //$this->connectionOptions = array("UID" => $this->user, "pwd" => $this->password, "Database" => $this->database, "LoginTimeout" => $this->loginTimeOut, "Encrypt" => $this->Encrypt);
                break;

            /* Privilegios sólo para lectura */
            case 'r':
                $this->server       = "house1234.db.8814249.hostedresource.com";
                $this->user         = "house1234";
                $this->password     = "Qwer1234!";
                $this->database     = $database;
                $this->loginTimeOut = 30;
                $this->Encrypt      = 1;
                $this->connectionOptions = array("UID" => $this->user, "pwd" => $this->password, "Database" => $this->database);
                //$this->connectionOptions = array("UID" => $this->user, "pwd" => $this->password, "Database" => $this->database, "LoginTimeout" => $this->loginTimeOut, "Encrypt" => $this->Encrypt);
                break;
        }
        $this->connect();
    }

    function connect() {
        $this->connection = sqlsrv_connect($this->server, $this->connectionOptions);
            if( $this->connection === false ) {
                 die( print_r( sqlsrv_errors(), true));
            }
    }

    function close() {
    	sqlsrv_close($this->connection);
        unset($this->connection);
    }

    function query($query) {
        $result = sqlsrv_query($this->connection, $query);
        if (!$result) {
            return false;
        }
        $rows = array();
        while ($row = sqlsrv_fetch_array($result)) {
            array_push($rows, $row);
        }
        return $rows;
    }

    function queryObject($query, $class) {
        $result = sqlsrv_query($this->connection, $query);
        if (!$result) {
            return false;
        }
        $rows = array();
        while ($row = sqlsrv_fetch_object($result, $class, $params)) {
            array_push($rows, $row);
        }
        return $rows;
    }

}

?>