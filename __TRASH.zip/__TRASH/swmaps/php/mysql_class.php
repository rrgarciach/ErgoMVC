<?php
require_once "sql_class.php";

class MySQL extends sql_class {

    private $server;
    private $user;
    private $password;
    private $connection;
    private $database;

    function __construct( $userType, $database ) {
        switch ($userType) {

            /* Privilegios para lectura y escritura */
            case 'w':
                $this->server       = "127.0.0.1";
                $this->user         = "root";
                $this->password     = "";
                $this->database     = $database;
                break;

            /* Privilegios sólo para lectura */
            case 'r':
                $this->server       = "127.0.0.1";
                $this->user         = "root";
                $this->password     = "";
                $this->database     = $database;
                break;
        }
        $this->connect();
    }

    function connect() {
        $this->connection   = mysql_connect($this->server, $this->user, $this->password) or die('Could not connect: ' . mysql_error());
        $dataBaseConn = mysql_select_db($this->database, $this->connection);
        if (!$dataBaseConn) {
            return false;
        }
        else {
            return true;
        }
    }

    function close() {
    	mysql_close($this->connection);
        unset($this->connection);
    }

    function query($query) {
        $result = mysql_query($query, $this->connection);
        if (!$result) {
            return false;
        }
        $rows = array();
        while ($row = mysql_fetch_array($result)) {
            array_push($rows, $row);
        }
        return $rows;
    }

}

?>