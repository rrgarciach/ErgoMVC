<?php

class Connection {

    /*//SERVER SPECS
    private $writeServerURL = "gcadmin.db.8814249.hostedresource.com";
    private $writeUser      = "gcadmin";
    private $writePassword  = "refGC1980";
    public  $writeUDB_write   = "";

    private $readServerURL  = "gcadmin.db.8814249.hostedresource.com";
    private $readUser       = "gcreader";
    private $readPassword   = "GCreader1980!";
    public  $readDB_read    = "";*/

    //DEBUG SPECS
    private $writeServerURL = "127.0.0.1";
    private $writeUser      = "root";
    private $writePassword  = "";
    public  $writeUDB_write   = "";

    private $readServerURL  = "127.0.0.1";
    private $readUser       = "root";
    private $readPassword   = "";
    public  $readDB_read    = "";

    function connRead($db){
            
            $this->readDB_read = mysql_connect($this->readServerURL, $this->readUser, $this->readPassword) or die('Could not connect: ' . mysql_error());
            mysql_select_db($db, $this->readDB_read) or die('Could not select database');

    }

    function closeRead(){
    	mysql_close($this->readDB_read);
        unset($this->readDB_read);
    }

    function connWriteU($db){
            
            $this->writeUDB_write = mysql_connect($this->writeServerURL, $this->writeUser, $this->writePassword) or die('Could not connect: ' . mysql_error());
            mysql_select_db($db, $this->writeUDB_write) or die('Could not select database');
    }

    function closeWriteU(){
        mysql_close($this->writeUDB_write);
        unset($this->writeUDB_write);
    }

}

?>