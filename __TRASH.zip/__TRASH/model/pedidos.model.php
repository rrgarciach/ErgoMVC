<?php

class PedidosController {

	private $conexion;

	/* Funcion ABRIR conexion a Base de Datos */ 
	private function conectarLecturaDB() {

		require_once "../inc/mysql.php";
		$this->conexion = new Connection();
		$this->conexion->connRead('gcadmin');
		
	}

	/* Funcion CERRAR conexion a Base de Datos */ 
	private function desconectarLecturaDB() {

		$this->conexion->closeRead();

	}

	/* Buscar pedido por No. de pedido.
	Retorna un arreglo con los registros encontrado. */ 
	public function leerPedidos( $atributo, $valor, $clausula="", $limite=0 ) {
		/* Implementacion de las clausulas y limtes para el query */
		if ($clausula!="") $clausula = " AND ".$clausula;
		if ($limite!=0) $limite = " LIMIT ".$limite;

		/* peticion QUERY para MySQL */
		$query = "SELECT * FROM pedidos WHERE $atributo='$valor'".$clausula.$limite;
		
		$this->conectarLecturaDB();

		$result = mysql_query($query, $this->conexion->readDB_read);
		if (!$result) {
			/* Se debe sobreescribir esto */ 
			echo "<h1>Error 201</h1>";
		}
		else {
			while ( $row = mysql_fetch_array($result) ) {
				return $row;
			}
		}

		$this->desconectarLecturaDB();

	}

	public function insertarPedidos() {

	}

	public function borrarPedidos() {

	}

	public function editarPedidos() {

	}

	public function productosPedidos( $id_pedido ) {

		/* peticion QUERY para MySQL */
		$query = "SELECT * FROM pedidos_detalle WHERE id_pedido='$id_pedido'";
		
		$this->conectarLecturaDB();

		$result = mysql_query($query, $this->conexion->readDB_read);
		if (!$result) {
			/* Se debe sobreescribir esto */ 
			echo "<h1>Error 201</h1>";
		}
		else {
			return mysql_fetch_array($result);
			
		}

		$this->desconectarLecturaDB();

	}

}

?>